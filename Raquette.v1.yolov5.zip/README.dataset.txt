# Raquette  > 2022-11-22 11:12pm
https://universe.roboflow.com/ecole-centrale-de-lyon/raquette

Provided by a Roboflow user
License: CC BY 4.0

